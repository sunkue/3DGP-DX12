#include "stdafx.h"

RANDOM Rand;